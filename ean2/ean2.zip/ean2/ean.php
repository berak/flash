<?PHP

function upcInfo($sean) 
{ 
	$upckey = "64eb69ab4972ba0c532913cdb6fea9223f5b925d";
	$upcs = $sean.length < 13 ? "00000" . $sean : $sean;
	$data = "<?xml version='1.0'?>" .
				"<methodCall><methodName>lookup</methodName>".
				"<params><param>".
				"<value>" .
				"<struct>" .
				"<member>" .
				"<name>rpc_key</name>" .
				"<value>$upckey</value>" .
				"</member>" .
				"<member>" .
				"<name>ean</name>" .
				"<value>$upcs</value>" .
				"</member>" .
				"</struct>".
				"</value>" .
				"</param></params></methodCall>";

    $fp = curl_init('http://www.upcdatabase.com/xmlrpc');
    curl_setopt($fp,CURLOPT_POST, 1);	
    curl_setopt($fp,CURLOPT_HTTPHEADER, array("Content-Type: text/xml;") );
    curl_setopt($fp,CURLOPT_POSTFIELDS, $data);

    $res = curl_exec($fp);
}  

function isbnInfo($sean) 
{ 
    $fp = curl_init("http://isbndb.com/api/books.xml?access_key=SAWYH84B&results=texts&index1=isbn&value1=$sean");
    $res = curl_exec($fp);
}  
?>
<html>
<head>
</head>

<body>
<?PHP
	$e = $HTTP_GET_VARS["ean"];
	if ( $e[0]=='9' && $e[1]=='7' && $e[2]=='8' ) // it's a book !
		isbnInfo( $e );
	else
		upcInfo( $e );
?>
</body>
</html>
